'use strict';
class DiscordWebhook {
  constructor({ fetchImpl = globalThis.fetch } = {}) { this.fetch = fetchImpl; }
  async send(url, content) {
    if (!/^https:\/\/((canary|ptb)\.)?discord(?:app)?\.com\/api\/webhooks\//.test(url || '')) throw new Error('Discord Webhook URL 格式不正確');
    const response = await this.fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'HoYo Daily Sign-in', content: String(content).slice(0, 1900) }) });
    if (!response.ok) throw new Error(`Discord 回應 ${response.status}`);
  }
}
module.exports = { DiscordWebhook };
