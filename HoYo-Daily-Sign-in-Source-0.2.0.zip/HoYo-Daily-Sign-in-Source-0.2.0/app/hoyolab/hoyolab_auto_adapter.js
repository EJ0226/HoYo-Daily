'use strict';

// Endpoint constants were derived from the unmodified hoyolab-auto snapshot in third_party.
// This adapter performs only HoYoLAB web check-in requests; it never touches a game client.
const GAME_CONFIG = Object.freeze({
  genshin: { actId: 'e202102251931481', rpcGame: 'hk4e', info: 'https://sg-hk4e-api.hoyolab.com/event/sol/info', sign: 'https://sg-hk4e-api.hoyolab.com/event/sol/sign' },
  starrail: { actId: 'e202303301540311', rpcGame: 'hkrpg', info: 'https://sg-public-api.hoyolab.com/event/luna/os/info', sign: 'https://sg-public-api.hoyolab.com/event/luna/os/sign' },
  zzz: { actId: 'e202406031448091', rpcGame: 'zzz', info: 'https://sg-public-api.hoyolab.com/event/luna/zzz/os/info', sign: 'https://sg-public-api.hoyolab.com/event/luna/zzz/os/sign' }
});

class HoyoLabAutoAdapter {
  constructor({ fetchImpl = globalThis.fetch, timeoutMs = 30_000 } = {}) { this.fetch = fetchImpl; this.timeoutMs = timeoutMs; }
  async checkIn({ game, cookie }) {
    const config = GAME_CONFIG[game];
    if (!config) return { status: 'api_error', message: '不支援的遊戲' };
    const normalizedCookie = normalizeCookie(cookie);
    if (!hasLoginCookie(normalizedCookie)) return { status: 'auth_invalid', message: 'Cookie 格式不完整：需要 ltuid/ltuid_v2 與 ltoken/ltoken_v2，請從 HoYoLAB 網頁的 Request Headers 複製 Cookie 值本身。' };
    const info = await this.#request(config.info, config, normalizedCookie);
    if (info.retcode !== 0) return this.#resultFromFailure(info, '讀取簽到狀態');
    if (info.data?.is_sign) return { status: 'already_done', message: '今日已簽到' };
    const sign = await this.#request(config.sign, config, normalizedCookie, 'POST');
    return sign.retcode === 0 ? { status: 'success', message: '簽到成功' } : this.#resultFromFailure(sign);
  }
  async #request(url, config, cookie, method = 'GET') {
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetch(`${url}?act_id=${encodeURIComponent(config.actId)}`, {
        method, signal: controller.signal,
        headers: { Cookie: cookie, 'x-rpc-signgame': config.rpcGame, 'User-Agent': 'HoYo Daily Sign-in Automation/0.1' }
      });
      if (!response.ok) { const error = new Error('HoYoLAB HTTP error'); error.code = 'API_ERROR'; throw error; }
      return await response.json();
    } catch (error) {
      if (error.name === 'AbortError' || error.cause?.code?.startsWith('UND_')) error.code = 'NETWORK_ERROR';
      throw error;
    } finally { clearTimeout(timer); }
  }
  #resultFromFailure(body, stage = '執行簽到') {
    const text = String(body?.message || '').toLowerCase(); const code = Number(body?.retcode);
    if (code === -5003 || text.includes('already signed')) return { status: 'already_done', message: '今日已簽到' };
    if ([-100, -10001, -1071].includes(code)) return { status: 'auth_invalid', message: `${stage}時 HoYoLAB 拒絕登入驗證（代碼 ${code}）。請重新從 HoYoLAB 網頁複製完整 Cookie 值；不要包含「Cookie:」前綴。` };
    if (code === -10101) return { status: 'api_error', message: 'HoYoLAB 今日帳號查詢數量已達限制（代碼 -10101）。' };
    return { status: 'api_error', message: `${stage}時 HoYoLAB API 回傳錯誤（代碼 ${Number.isFinite(code) ? code : '未知'}）。` };
  }
}
function normalizeCookie(input) {
  const raw = String(input || '').trim().replace(/^cookie\s*:\s*/i, '');
  const wanted = new Set(['ltuid', 'ltuid_v2', 'ltoken', 'ltoken_v2', 'ltmid', 'ltmid_v2', 'account_id', 'account_id_v2', 'account_mid', 'account_mid_v2', 'cookie_token', 'cookie_token_v2']);
  const values = new Map();
  for (const part of raw.replace(/[\r\n]+/g, ';').split(';')) { const index = part.indexOf('='); if (index > 0) { const key = part.slice(0, index).trim(); const value = part.slice(index + 1).trim(); if (wanted.has(key) && value) values.set(key, value); } }
  return [...values].map(([key, value]) => `${key}=${value}`).join('; ');
}
function hasLoginCookie(cookie) { return /(?:^|; )ltuid(?:_v2)?=/.test(cookie) && /(?:^|; )ltoken(?:_v2)?=/.test(cookie); }
module.exports = { HoyoLabAutoAdapter, GAME_CONFIG, normalizeCookie, hasLoginCookie };
