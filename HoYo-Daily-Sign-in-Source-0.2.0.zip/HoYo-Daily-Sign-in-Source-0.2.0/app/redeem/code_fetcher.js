'use strict';
const SOURCE_URL = 'https://db.hashblen.com/codes';
const GAME_KEYS = { genshin: 'genshin', hsr: 'starrail', starrail: 'starrail', zzz: 'zzz' };
class CodeFetcher {
  constructor({ fetchImpl = globalThis.fetch, sourceUrl = SOURCE_URL } = {}) { this.fetch = fetchImpl; this.sourceUrl = sourceUrl; }
  async fetchCodes() {
    const response = await this.fetch(this.sourceUrl, { headers: { Accept: 'application/json' } }); if (!response.ok) throw new Error(`Code 來源回應 ${response.status}`);
    const body = await response.json(); const found = [];
    for (const [sourceGame, entries] of Object.entries(body || {})) { const game = GAME_KEYS[sourceGame]; if (!game || !Array.isArray(entries)) continue; for (const entry of entries) { const code = String(entry?.code || '').trim().toUpperCase(); if (/^[A-Z0-9]{4,32}$/.test(code)) found.push({ game, code, discoveredAt: entry.added_at ? new Date(entry.added_at * 1000).toISOString() : new Date().toISOString() }); } }
    return found;
  }
}
module.exports = { CodeFetcher, SOURCE_URL };
