'use strict';
const CONFIG = { genshin: { id: 2, biz: 'hk4e_global', endpoint: 'https://sg-hk4e-api.hoyoverse.com/common/apicdkey/api/webExchangeCdkey', post: false }, starrail: { id: 6, biz: 'hkrpg_global', endpoint: 'https://sg-hkrpg-api.hoyoverse.com/common/apicdkey/api/webExchangeCdkeyRisk', post: true }, zzz: { id: 8, biz: 'nap_global', endpoint: 'https://public-operation-nap.hoyoverse.com/common/apicdkey/api/webExchangeCdkey', post: false } };
class HoyoLabRedeemAdapter {
  constructor({ fetchImpl = globalThis.fetch } = {}) { this.fetch = fetchImpl; }
  async redeem({ game, code, cookie, uid, server }) {
    const config = CONFIG[game]; if (!config || !cookie) return { status: 'auth_invalid', message: '找不到登入資料' };
    const role = uid && server ? { uid, server } : await this.#role(config.id, cookie); if (!role) return { status: 'api_error', message: '找不到此遊戲角色或伺服器' };
    const headers = { Cookie: cookie, Accept: 'application/json, text/plain, */*', 'x-rpc-client_type': '4', 'x-rpc-app_version': '2.34.1' }; let response;
    if (config.post) response = await this.fetch(config.endpoint, { method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' }, body: JSON.stringify({ game_biz: config.biz, uid: role.uid, region: role.server, cdkey: code, lang: 'en' }) });
    else { const url = new URL(config.endpoint); url.search = new URLSearchParams({ lang: 'en', game_biz: config.biz, uid: role.uid, region: role.server, cdkey: code }); response = await this.fetch(url, { headers }); }
    const body = await response.json(); if (body.retcode === 0) return { status: 'success', message: '兌換成功' }; if (body.retcode === -2016) { const seconds = Number(String(body.message || '').match(/(\d+)\s*second/i)?.[1] || 5); return { status: 'cooldown', message: `HoYoLAB 冷卻中，${seconds} 秒後自動重試`, retryAfterMs: Math.min(Math.max(seconds, 1), 30) * 1000 }; } if ([-2017, -2018].includes(body.retcode)) return { status: 'already_used', message: '此兌換碼已使用' }; if ([-100, -10001, -1071].includes(body.retcode)) return { status: 'auth_invalid', message: `HoYoLAB 拒絕登入驗證（代碼 ${body.retcode}）` }; return { status: 'api_error', message: `兌換失敗：${body.message || '未知錯誤'}（代碼 ${body.retcode}）` };
  }
  async #role(gameId, cookie) { const url = new URL('https://bbs-api-os.hoyolab.com/game_record/card/wapi/getGameRecordCard'); const match = cookie.match(/(?:^|; )ltuid(?:_v2)?=([^;]+)/); if (!match) return null; url.searchParams.set('uid', match[1]); const res = await this.fetch(url, { headers: { Cookie: cookie } }); const body = await res.json(); const role = body?.data?.list?.find(item => item.game_id === gameId); return role ? { uid: role.game_role_id, server: role.region } : null; }
}
module.exports = { HoyoLabRedeemAdapter };
