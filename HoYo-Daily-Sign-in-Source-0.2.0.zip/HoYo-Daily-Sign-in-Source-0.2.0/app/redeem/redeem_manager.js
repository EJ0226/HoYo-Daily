'use strict';
const { GAMES } = require('../shared/games');
class RedeemManager {
  constructor({ accounts, secrets, client, logs, db }) { this.accounts = accounts; this.secrets = secrets; this.client = client; this.logs = logs; this.db = db; }
  async redeem({ game, code, accountIds = null }) {
    if (!GAMES[game]) throw new Error('不支援的遊戲'); const normalized = String(code || '').trim().toUpperCase();
    if (!/^[A-Z0-9]{4,32}$/.test(normalized)) throw new Error('兌換碼格式不正確');
    let codeRow = this.db.prepare('SELECT id FROM redeem_codes WHERE game = ? AND code = ?').get(game, normalized);
    if (!codeRow) { this.db.prepare('INSERT INTO redeem_codes (game, code, discovered_at) VALUES (?, ?, ?)').run(game, normalized, new Date().toISOString()); this.db.persist(); codeRow = this.db.prepare('SELECT id FROM redeem_codes WHERE game = ? AND code = ?').get(game, normalized); }
    const results = [];
    for (const account of this.accounts.activeForRedeem(game).filter(account => !accountIds || accountIds.includes(account.id))) {
      if (this.db.prepare('SELECT 1 FROM redeem_results WHERE code_id = ? AND account_id = ?').get(codeRow.id, account.id)) {
        const entry = { accountId: account.id, accountName: account.name, game, status: 'already_processed', message: `Code ${normalized}：此帳號已處理過此兌換碼` };
        this.logs.write({ ...entry, taskType: 'redeem' }); results.push(entry); continue;
      }
      let result;
      try {
        const request = { game, code: normalized, cookie: this.secrets.get(account.secretRef), uid: account.uid, server: account.server };
        result = await this.client.redeem(request);
        if (result.status === 'cooldown') { await delay(result.retryAfterMs); result = await this.client.redeem(request); }
      } catch { result = { status: 'network_error', message: '網路連線失敗' }; }
      const entry = { accountId: account.id, accountName: account.name, game, ...result, message: `Code ${normalized}：${result.message}` };
      this.db.prepare('INSERT INTO redeem_results (code_id, account_id, status, message, executed_at) VALUES (?, ?, ?, ?, ?)').run(codeRow.id, account.id, result.status, result.message, new Date().toISOString()); this.db.persist(); this.logs.write({ ...entry, taskType: 'redeem' }); results.push(entry);
    }
    return results;
  }
  async redeemMany(codes, { intervalMs = 10_000, wait = delay, accountIds = null } = {}) {
    const unique = [...new Map(codes.map(item => [`${item.game}:${String(item.code).toUpperCase()}`, item])).values()];
    const results = [];
    for (let index = 0; index < unique.length; index += 1) {
      if (index > 0) await wait(intervalMs);
      results.push(...await this.redeem({ ...unique[index], accountIds }));
    }
    return results;
  }
}
function delay(milliseconds) { return new Promise(resolve => setTimeout(resolve, milliseconds)); }
module.exports = { RedeemManager };
