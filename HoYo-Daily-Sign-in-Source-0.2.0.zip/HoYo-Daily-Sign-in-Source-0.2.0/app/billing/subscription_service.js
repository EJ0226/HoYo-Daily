'use strict';
const { OFFLINE_PLANS, verifyLicenseCode } = require('./offline_license');

const TRIAL_DURATION_MS = 7 * 24 * 60 * 60 * 1000;
const PLANS = Object.freeze({
  free: { id: 'free', name: '免費版', price: 0, interval: null },
  monthly: { id: 'monthly', name: 'Premium 月費', price: 99, interval: 'month' },
  annual: { id: 'annual', name: 'Premium 年費', price: 599, interval: 'year' }
});

function parseDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

class SubscriptionService {
  constructor(settings, { now = () => new Date() } = {}) { this.settings = settings; this.now = now; }

  getStatus() {
    const saved = this.settings.get('subscription', {});
    const now = this.now();
    const trialStartedAt = parseDate(saved.trialStartedAt);
    const paidUntil = parseDate(saved.paidUntil);
    const paidPlan = PLANS[saved.planId];
    const paidActive = Boolean(paidPlan && paidPlan.id !== 'free' && paidUntil && paidUntil > now);
    const offline = saved.offlineLicense || {}; const offlinePlan = OFFLINE_PLANS[offline.planId]; const offlineEndsAt = parseDate(offline.expiresAt); const offlineActive = Boolean(offlinePlan && offlineEndsAt && offlineEndsAt > now);
    const trialEndsAt = trialStartedAt ? new Date(trialStartedAt.getTime() + TRIAL_DURATION_MS) : null;
    const trialActive = Boolean(!paidActive && trialEndsAt && trialEndsAt > now);
    const remainingMs = trialActive ? trialEndsAt.getTime() - now.getTime() : 0;
    const activePlan = paidActive ? paidPlan : offlineActive ? { id: offlinePlan.id, name: offlinePlan.name, price: 0, interval: null } : PLANS.free;
    const isOfflineTrial = offlineActive && offlinePlan.id === 'trial7';
    return {
      plan: activePlan,
      status: paidActive ? 'active' : offlineActive ? (isOfflineTrial ? 'trial' : 'active') : trialActive ? 'trial' : (offline.planId || trialStartedAt) ? 'expired' : 'not_started',
      isPremiumServiceActive: paidActive || offlineActive || trialActive,
      trialStartedAt: trialStartedAt?.toISOString() || null,
      trialEndsAt: trialEndsAt?.toISOString() || null,
      trialDaysRemaining: isOfflineTrial ? Math.ceil((offlineEndsAt.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)) : trialActive ? Math.ceil(remainingMs / (24 * 60 * 60 * 1000)) : 0,
      subscriptionEndsAt: paidActive ? paidUntil.toISOString() : offlineActive ? offlineEndsAt.toISOString() : null,
      offlineLicense: offlineActive ? { id: offline.id, planId: offlinePlan.id } : null,
      prices: { monthly: PLANS.monthly.price, annual: PLANS.annual.price },
      // This only describes optional hosted services. Local AGPL features remain usable.
      premiumServices: ['跨裝置授權', '雲端同步設定', '進階通知摘要', '優先支援']
    };
  }

  startTrial() {
    const existing = this.settings.get('subscription', {});
    if (existing.trialStartedAt) return this.getStatus();
    this.settings.set('subscription', { ...existing, planId: 'free', trialStartedAt: this.now().toISOString() });
    return this.getStatus();
  }

  setRemoteLicense({ planId, paidUntil, licenseId }) {
    if (!PLANS[planId] || planId === 'free') throw new Error('無效的訂閱方案');
    const end = parseDate(paidUntil);
    if (!end || end <= this.now()) throw new Error('授權到期日無效');
    const existing = this.settings.get('subscription', {});
    this.settings.set('subscription', { ...existing, planId, paidUntil: end.toISOString(), licenseId: String(licenseId || '') });
    return this.getStatus();
  }

  redeemOfflineCode(code, publicKeyPem) {
    const license = verifyLicenseCode(code, publicKeyPem); const current = this.getStatus();
    if (current.isPremiumServiceActive) throw new Error(`目前方案尚未到期（${current.plan.name}），請到期後再輸入新的授權碼。`);
    const saved = this.settings.get('subscription', {}); const used = Array.isArray(saved.usedOfflineLicenseIds) ? saved.usedOfflineLicenseIds : [];
    if (used.includes(license.id)) throw new Error('這組授權碼已在此裝置使用過');
    const activatedAt = this.now(); const expiresAt = new Date(activatedAt.getTime() + license.plan.durationDays * 24 * 60 * 60 * 1000);
    this.settings.set('subscription', { ...saved, offlineLicense: { id: license.id, planId: license.plan.id, activatedAt: activatedAt.toISOString(), expiresAt: expiresAt.toISOString(), note: license.note }, usedOfflineLicenseIds: [...used, license.id].slice(-100) });
    return this.getStatus();
  }
}

module.exports = { SubscriptionService, PLANS, TRIAL_DURATION_MS };
