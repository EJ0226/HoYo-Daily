'use strict';
const crypto = require('node:crypto');

const OFFLINE_PLANS = Object.freeze({ trial7: { id: 'trial7', name: 'Premium 7 天試用', durationDays: 7 }, premium_month: { id: 'premium_month', name: 'Premium 1 個月', durationDays: 30 }, premium_year: { id: 'premium_year', name: 'Premium 1 年', durationDays: 365 } });

function decode(code) {
  const parts = String(code || '').trim().replace(/\s+/g, '').split('.');
  if (parts.length !== 3 || parts[0] !== 'HD1') throw new Error('授權碼格式不正確');
  try { return { payloadBytes: Buffer.from(parts[1], 'base64url'), payload: JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8')), signature: Buffer.from(parts[2], 'base64url') }; } catch { throw new Error('授權碼內容無法讀取'); }
}
function verifyLicenseCode(code, publicKeyPem) {
  if (!publicKeyPem || publicKeyPem.includes('REPLACE_WITH')) throw new Error('此版本尚未設定授權驗證金鑰');
  const decoded = decode(code);
  if (!decoded.payload || decoded.payload.v !== 1 || !OFFLINE_PLANS[decoded.payload.plan] || typeof decoded.payload.id !== 'string' || decoded.payload.id.length < 8) throw new Error('授權碼內容無效');
  let valid = false; try { valid = crypto.verify(null, decoded.payloadBytes, publicKeyPem, decoded.signature); } catch { throw new Error('授權驗證金鑰無效'); }
  if (!valid) throw new Error('授權碼簽章無效');
  return { id: decoded.payload.id, plan: OFFLINE_PLANS[decoded.payload.plan], issuedAt: decoded.payload.iat || null, note: typeof decoded.payload.note === 'string' ? decoded.payload.note.slice(0, 80) : '' };
}
function issueLicenseCode({ privateKeyPem, planId, id, issuedAt = new Date().toISOString(), note = '' }) {
  if (!OFFLINE_PLANS[planId]) throw new Error('未知授權方案'); if (!id || String(id).length < 8) throw new Error('授權碼序號至少需要 8 個字元');
  const payload = Buffer.from(JSON.stringify({ v: 1, id: String(id), plan: planId, iat: issuedAt, note: String(note).slice(0, 80) }), 'utf8');
  return `HD1.${payload.toString('base64url')}.${crypto.sign(null, payload, privateKeyPem).toString('base64url')}`;
}
module.exports = { OFFLINE_PLANS, verifyLicenseCode, issueLicenseCode };
