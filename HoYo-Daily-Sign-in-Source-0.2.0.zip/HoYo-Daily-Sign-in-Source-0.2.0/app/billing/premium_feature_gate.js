'use strict';

const FREE_ACCOUNT_LIMIT = 1;
const PREMIUM_FEATURES = Object.freeze({
  multipleAccounts: '多帳號管理',
  dailySchedule: '每日自動簽到排程',
  codePolling: '自動檢查與兌換公開 Code',
  discord: 'Discord Webhook 通知',
  startup: 'Windows 開機自動啟動'
});

class PremiumFeatureGate {
  constructor(subscription) { this.subscription = subscription; }
  isPremium() { return this.subscription.getStatus().isPremiumServiceActive; }
  assert(feature) { if (!this.isPremium()) throw new Error(`${PREMIUM_FEATURES[feature] || '此功能'}需要 Premium 授權碼。免費版可使用單一帳號的手動簽到與手動兌換。`); }
  assertCanCreateAccount(accountCount) { if (accountCount >= FREE_ACCOUNT_LIMIT) this.assert('multipleAccounts'); }
  manualAccountIds(accounts) { return this.isPremium() ? accounts.map(account => account.id) : accounts.slice(0, FREE_ACCOUNT_LIMIT).map(account => account.id); }
}

module.exports = { PremiumFeatureGate, PREMIUM_FEATURES, FREE_ACCOUNT_LIMIT };
