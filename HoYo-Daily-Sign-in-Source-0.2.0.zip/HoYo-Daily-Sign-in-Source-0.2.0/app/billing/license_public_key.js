'use strict';

// Public verification key only. The private key must remain outside all releases.
const LICENSE_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAPATVvoYPvMaBFfNOn+EKXaIMvzBh1KBSWgfWHV2P/0Q=
-----END PUBLIC KEY-----`;

module.exports = { LICENSE_PUBLIC_KEY_PEM };
