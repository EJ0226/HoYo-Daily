'use strict';
function validateTime(time) { if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error('每日執行時間需為 HH:mm 格式'); }
function nextRunAt(time, now = new Date()) { validateTime(time); const [hours, minutes] = time.split(':').map(Number); const next = new Date(now); next.setHours(hours, minutes, 0, 0); if (next <= now) next.setDate(next.getDate() + 1); return next; }
class DailyScheduler {
  constructor({ run, onSchedule = () => {}, clock = { setTimeout, clearTimeout }, now = () => new Date() }) { this.run = run; this.onSchedule = onSchedule; this.clock = clock; this.now = now; this.timer = null; }
  configure({ enabled, time }) { this.stop(); if (!enabled) return null; validateTime(time); const next = nextRunAt(time, this.now()); this.timer = this.clock.setTimeout(async () => { try { await this.run(); } finally { this.configure({ enabled: true, time }); } }, next.getTime() - this.now().getTime()); this.onSchedule(next); return next; }
  stop() { if (this.timer) this.clock.clearTimeout(this.timer); this.timer = null; }
}
module.exports = { DailyScheduler, nextRunAt, validateTime };
