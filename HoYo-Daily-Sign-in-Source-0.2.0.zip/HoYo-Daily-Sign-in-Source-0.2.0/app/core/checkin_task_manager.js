'use strict';

const { GAMES } = require('../shared/games');

const TaskStatus = Object.freeze({ SUCCESS: 'success', ALREADY_DONE: 'already_done', AUTH_INVALID: 'auth_invalid', API_ERROR: 'api_error', NETWORK_ERROR: 'network_error', UNKNOWN_ERROR: 'unknown_error' });

class CheckinTaskManager {
  constructor({ accounts, secrets, checkinClient, logs }) {
    this.accounts = accounts; this.secrets = secrets; this.checkinClient = checkinClient; this.logs = logs;
  }
  async run({ games = Object.keys(GAMES), accountIds = null } = {}) {
    const results = [];
    for (const game of games) {
      for (const account of this.accounts.activeForCheckin(game).filter(account => !accountIds || accountIds.includes(account.id))) results.push(await this.#runAccount(account));
    }
    return results;
  }
  async #runAccount(account) {
    let status; let message;
    try {
      const cookie = this.secrets.get(account.secretRef);
      if (!cookie) throw new Error('Credential missing');
      ({ status, message } = await this.checkinClient.checkIn({ game: account.game, uid: account.uid, server: account.server, cookie }));
    } catch (error) {
      status = classifyError(error); message = userMessage(status);
    }
    const result = { accountId: account.id, accountName: account.name, game: account.game, status, message };
    this.logs.write({ ...result, taskType: 'checkin' });
    return result;
  }
}
function classifyError(error) {
  if (error && error.code === 'AUTH_INVALID') return TaskStatus.AUTH_INVALID;
  if (error && error.code === 'NETWORK_ERROR') return TaskStatus.NETWORK_ERROR;
  if (error && error.code === 'API_ERROR') return TaskStatus.API_ERROR;
  return TaskStatus.UNKNOWN_ERROR;
}
function userMessage(status) {
  return status === TaskStatus.AUTH_INVALID ? 'Token 或 Cookie 已失效，請重新登入' : status === TaskStatus.NETWORK_ERROR ? '網路連線失敗，將於下次排程重試' : status === TaskStatus.API_ERROR ? 'HoYoLAB API 回傳錯誤' : '任務執行時發生未知錯誤';
}
module.exports = { CheckinTaskManager, TaskStatus, classifyError };
