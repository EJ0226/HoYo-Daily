'use strict';

// Production code injects Electron's safeStorage. It encrypts values using Windows DPAPI.
class ElectronSafeStorage {
  constructor(safeStorage, db) { this.safeStorage = safeStorage; this.db = db; }
  set(ref, plaintext) {
    if (!this.safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is unavailable');
    const encrypted = this.safeStorage.encryptString(plaintext);
    this.db.prepare(`INSERT INTO secrets (ref, encrypted_value, updated_at) VALUES (?, ?, ?)
      ON CONFLICT(ref) DO UPDATE SET encrypted_value = excluded.encrypted_value, updated_at = excluded.updated_at`)
      .run(ref, encrypted, new Date().toISOString());
    this.db.persist();
  }
  get(ref) {
    const row = this.db.prepare('SELECT encrypted_value AS encryptedValue FROM secrets WHERE ref = ?').get(ref);
    return row ? this.safeStorage.decryptString(Buffer.from(row.encryptedValue)) : null;
  }
  delete(ref) { this.db.prepare('DELETE FROM secrets WHERE ref = ?').run(ref); this.db.persist(); }
}
module.exports = { ElectronSafeStorage };
