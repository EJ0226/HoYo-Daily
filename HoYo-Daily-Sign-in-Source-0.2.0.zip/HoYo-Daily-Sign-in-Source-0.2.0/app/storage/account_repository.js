'use strict';

const { assertGame } = require('../shared/games');

class AccountRepository {
  constructor(db) { this.db = db; }

  save(account) {
    const now = new Date().toISOString();
    this.db.prepare('INSERT INTO accounts (id, name, enabled, secret_ref, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(account.id, account.name, account.enabled ? 1 : 0, account.secretRef, now, now);
    for (const game of account.games) {
      assertGame(game.game);
      this.db.prepare('INSERT INTO account_games (account_id, game, uid, server, enabled, checkin_enabled, redeem_enabled) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(account.id, game.game, game.uid || null, game.server || null, game.enabled ? 1 : 0, game.checkinEnabled ? 1 : 0, game.redeemEnabled ? 1 : 0);
    }
  }

  activeForCheckin(game) {
    assertGame(game);
    return this.db.prepare(`SELECT a.id, a.name, a.secret_ref AS secretRef, g.game, g.uid, g.server
      FROM accounts a JOIN account_games g ON g.account_id = a.id
      WHERE a.enabled = 1 AND g.game = ? AND g.enabled = 1 AND g.checkin_enabled = 1`).all(game);
  }
  activeForRedeem(game) {
    assertGame(game);
    // V1 account UI originally did not expose the redeem toggle, and existing accounts
    // were persisted with it disabled. Treat an enabled game as redeem-enabled until
    // the per-game toggle UI is introduced, so users are not silently excluded.
    return this.db.prepare(`SELECT a.id, a.name, a.secret_ref AS secretRef, g.game, g.uid, g.server FROM accounts a JOIN account_games g ON g.account_id = a.id WHERE a.enabled = 1 AND g.game = ? AND g.enabled = 1`).all(game);
  }

  list() {
    return this.db.prepare(`SELECT a.id, a.name, a.enabled, a.secret_ref AS secretRef, g.game, g.uid, g.server,
      g.enabled AS gameEnabled, g.checkin_enabled AS checkinEnabled, g.redeem_enabled AS redeemEnabled
      FROM accounts a LEFT JOIN account_games g ON g.account_id = a.id ORDER BY a.created_at, g.game`).all();
  }

  setEnabled(id, enabled) {
    this.db.prepare('UPDATE accounts SET enabled = ?, updated_at = ? WHERE id = ?').run(enabled ? 1 : 0, new Date().toISOString(), id);
    this.db.persist();
  }
  delete(id) {
    const account = this.db.prepare('SELECT secret_ref AS secretRef FROM accounts WHERE id = ?').get(id);
    if (!account) return null;
    this.db.prepare('DELETE FROM accounts WHERE id = ?').run(id); this.db.persist(); return account;
  }
}

module.exports = { AccountRepository };
