'use strict';

const SENSITIVE_KEYS = /cookie|token|webhook|password|secret/i;
function redact(value) {
  if (typeof value === 'string') return value.replace(/(cookie|token|webhook)[^\s]*/gi, '$1=********');
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, SENSITIVE_KEYS.test(key) ? '********' : redact(item)]));
}
class ExecutionLogRepository {
  constructor(db) { this.db = db; }
  write(entry) {
    const safeMessage = typeof entry.message === 'string' ? redact(entry.message) : JSON.stringify(redact(entry.message));
    this.db.prepare('INSERT INTO execution_logs (account_id, game, task_type, status, message, created_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(entry.accountId || null, entry.game || null, entry.taskType, entry.status, safeMessage, new Date().toISOString());
    this.db.persist();
  }
  latest(limit = 100) {
    return this.db.prepare(`SELECT l.id, l.account_id AS accountId, a.name AS accountName, l.game, l.task_type AS taskType,
      l.status, l.message, l.created_at AS createdAt FROM execution_logs l LEFT JOIN accounts a ON a.id = l.account_id
      ORDER BY l.id DESC LIMIT ?`).all(limit);
  }
}
module.exports = { ExecutionLogRepository, redact };
