'use strict';
class SettingsRepository {
  constructor(db) { this.db = db; }
  get(key, fallback = null) { const row = this.db.prepare('SELECT value FROM settings WHERE key = ?').get(key); return row ? JSON.parse(row.value) : fallback; }
  set(key, value) { this.db.prepare(`INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`).run(key, JSON.stringify(value), new Date().toISOString()); this.db.persist(); }
}
module.exports = { SettingsRepository };
