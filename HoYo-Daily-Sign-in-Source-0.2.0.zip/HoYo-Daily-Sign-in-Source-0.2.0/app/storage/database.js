'use strict';

const fs = require('node:fs');
const path = require('node:path');
const initSqlJs = require('sql.js');

class Statement {
  constructor(statement) { this.statement = statement; }
  run(...params) { this.statement.bind(params); this.statement.step(); this.statement.free(); }
  all(...params) {
    this.statement.bind(params); const rows = [];
    while (this.statement.step()) rows.push(this.statement.getAsObject());
    this.statement.free(); return rows;
  }
  get(...params) { return this.all(...params)[0]; }
}

class PersistentSqlite {
  constructor(database, filename) { this.database = database; this.filename = filename; }
  exec(sql) { this.database.run(sql); this.#persist(); }
  prepare(sql) { return new Statement(this.database.prepare(sql)); }
  persist() { this.#persist(); }
  close() { this.#persist(); this.database.close(); }
  #persist() {
    if (this.filename === ':memory:') return;
    fs.mkdirSync(path.dirname(this.filename), { recursive: true });
    fs.writeFileSync(this.filename, Buffer.from(this.database.export()));
  }
}

async function openDatabase(filename) {
  const SQL = await initSqlJs({ locateFile: file => path.join(path.dirname(require.resolve('sql.js')), file) });
  const bytes = filename !== ':memory:' && fs.existsSync(filename) ? fs.readFileSync(filename) : undefined;
  const db = new PersistentSqlite(new SQL.Database(bytes), filename);
  db.exec('PRAGMA foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
      secret_ref TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS secrets (
      ref TEXT PRIMARY KEY, encrypted_value BLOB NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS account_games (
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      game TEXT NOT NULL, uid TEXT, server TEXT,
      enabled INTEGER NOT NULL DEFAULT 1, checkin_enabled INTEGER NOT NULL DEFAULT 1,
      redeem_enabled INTEGER NOT NULL DEFAULT 1,
      PRIMARY KEY (account_id, game)
    );
    CREATE TABLE IF NOT EXISTS execution_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, account_id TEXT REFERENCES accounts(id) ON DELETE SET NULL,
      game TEXT, task_type TEXT NOT NULL, status TEXT NOT NULL, message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS redeem_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT, game TEXT NOT NULL, code TEXT NOT NULL,
      discovered_at TEXT NOT NULL, UNIQUE(game, code)
    );
    CREATE TABLE IF NOT EXISTS redeem_results (
      code_id INTEGER NOT NULL REFERENCES redeem_codes(id) ON DELETE CASCADE,
      account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      status TEXT NOT NULL, message TEXT NOT NULL, executed_at TEXT NOT NULL,
      PRIMARY KEY(code_id, account_id)
    );
  `);
  return db;
}

module.exports = { openDatabase };
