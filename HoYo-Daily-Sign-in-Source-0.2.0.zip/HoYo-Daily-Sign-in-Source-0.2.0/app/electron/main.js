'use strict';

const path = require('node:path');
const crypto = require('node:crypto');
const { app, BrowserWindow, ipcMain, safeStorage } = require('electron');
const { openDatabase } = require('../storage/database');
const { AccountRepository } = require('../storage/account_repository');
const { ElectronSafeStorage } = require('../storage/secret_store');
const { ExecutionLogRepository } = require('../storage/execution_log_repository');
const { SettingsRepository } = require('../storage/settings_repository');
const { CheckinTaskManager } = require('../core/checkin_task_manager');
const { DailyScheduler } = require('../core/daily_scheduler');
const { HoyoLabAutoAdapter } = require('../hoyolab/hoyolab_auto_adapter');
const { RedeemManager } = require('../redeem/redeem_manager');
const { HoyoLabRedeemAdapter } = require('../redeem/hoyolab_redeem_adapter');
const { CodeFetcher } = require('../redeem/code_fetcher');
const { DiscordWebhook } = require('../notifications/discord_webhook');
const { SubscriptionService } = require('../billing/subscription_service');
const { LICENSE_PUBLIC_KEY_PEM } = require('../billing/license_public_key');
const { PremiumFeatureGate } = require('../billing/premium_feature_gate');
const { GAMES } = require('../shared/games');

let database; let accounts; let secrets; let logs; let settings; let subscriptions; let premium; let checkins; let redeems; let codes; let discord; let scheduler; let nextRun = null; let codeTimer = null;

function createWindow() {
  const window = new BrowserWindow({ width: 1100, height: 720, minWidth: 900, minHeight: 620,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  window.removeMenu();
  window.loadFile(path.join(__dirname, '../gui/index.html'));
}

function cookieHeader(cookies) {
  const permitted = new Set(['ltuid', 'ltuid_v2', 'ltoken', 'ltoken_v2', 'ltmid', 'ltmid_v2', 'account_id', 'account_id_v2', 'account_mid', 'account_mid_v2', 'cookie_token', 'cookie_token_v2']);
  return cookies.filter(cookie => permitted.has(cookie.name) && cookie.value).map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
}

async function getHoyoLabCookie() {
  const login = new BrowserWindow({ width: 1120, height: 760, parent: BrowserWindow.getFocusedWindow(), modal: true,
    webPreferences: { partition: 'persist:hoyolab-login', contextIsolation: true, nodeIntegration: false } });
  login.removeMenu();
  const authSession = login.webContents.session;
  await login.loadURL('https://www.hoyolab.com/home');
  return new Promise(resolve => {
    login.once('closed', async () => {
      try {
        const cookie = cookieHeader(await authSession.cookies.get({ domain: '.hoyolab.com' }));
        if (!/(?:^|; )ltuid(?:_v2)?=/.test(cookie) || !/(?:^|; )ltoken(?:_v2)?=/.test(cookie)) throw new Error('尚未偵測到 HoYoLAB 登入 Cookie。請在官方視窗完成登入後再關閉視窗。');
        resolve({ ok: true, cookie });
      } catch (error) { resolve({ ok: false, error: error.message }); }
    });
  });
}

function manualAccountIds() { return premium.manualAccountIds(accountView()); }
async function notify(text) {
  if (!premium.isPremium()) return;
  const config = settings.get('discord', { enabled: false }); if (!config.enabled) return;
  const url = secrets.get('discord:webhook'); if (!url) return;
  try { await discord.send(url, text); } catch (error) { logs.write({ taskType: 'notification', status: 'error', message: `Discord 通知失敗：${error.message}` }); }
}
async function runCodes({ accountIds = null } = {}) {
  try {
    const found = await codes.fetchCodes(); const results = await redeems.redeemMany(found, { intervalMs: 10_000, accountIds });
    if (results.length) await notify(`兌換碼處理完成\n${results.map(result => `${result.accountName} · ${result.game} · ${result.message}`).join('\n')}`);
    return results;
  } catch (error) { logs.write({ taskType: 'code_fetch', status: 'network_error', message: `取得兌換碼失敗：${error.message}` }); throw error; }
}
function configureCodePolling() { if (codeTimer) clearInterval(codeTimer); const config = settings.get('code_polling', { enabled: false, minutes: 30 }); if (config.enabled && premium.isPremium()) codeTimer = setInterval(() => { runCodes().catch(() => {}); }, Math.max(5, config.minutes) * 60_000); }

function accountView() {
  const grouped = new Map();
  for (const row of accounts.list()) {
    if (!grouped.has(row.id)) grouped.set(row.id, { id: row.id, name: row.name, enabled: Boolean(row.enabled), games: [] });
    if (row.game) grouped.get(row.id).games.push({ game: row.game, uid: row.uid, enabled: Boolean(row.gameEnabled), checkinEnabled: Boolean(row.checkinEnabled), redeemEnabled: Boolean(row.redeemEnabled) });
  }
  return [...grouped.values()];
}

app.whenReady().then(async () => {
  database = await openDatabase(path.join(app.getPath('userData'), 'hoyo-daily.sqlite'));
  accounts = new AccountRepository(database);
  secrets = new ElectronSafeStorage(safeStorage, database);
  logs = new ExecutionLogRepository(database); settings = new SettingsRepository(database);
  subscriptions = new SubscriptionService(settings);
  premium = new PremiumFeatureGate(subscriptions);
  checkins = new CheckinTaskManager({ accounts, secrets, logs, checkinClient: new HoyoLabAutoAdapter() });
  redeems = new RedeemManager({ accounts, secrets, logs, db: database, client: new HoyoLabRedeemAdapter() });
  codes = new CodeFetcher(); discord = new DiscordWebhook();
  scheduler = new DailyScheduler({ run: async () => { if (!premium.isPremium()) { nextRun = null; return []; } const results = await checkins.run(); await notify(`每日簽到完成\n${results.map(result => `${result.accountName} · ${result.game} · ${result.message}`).join('\n')}`); return results; }, onSchedule: date => { nextRun = date.toISOString(); } });
  const storedSchedule = settings.get('schedule', { enabled: false, time: '04:00' }); scheduler.configure({ ...storedSchedule, enabled: storedSchedule.enabled && premium.isPremium() });
  configureCodePolling();
  const startup = settings.get('startup', { enabled: false });
  app.setLoginItemSettings({ openAtLogin: startup.enabled && premium.isPremium(), openAsHidden: startup.enabled && premium.isPremium() });
  ipcMain.handle('accounts:list', () => accountView());
  ipcMain.handle('dashboard:get', () => {
    const values = accountView(); const gameCounts = Object.fromEntries(Object.keys(GAMES).map(game => [game, 0]));
    values.forEach(account => account.games.filter(game => game.enabled).forEach(game => { gameCounts[game.game] += 1; }));
    const today = new Date().toISOString().slice(0, 10); const records = logs.latest(500).filter(log => log.createdAt.slice(0, 10) === today);
    return { accounts: values.length, gameCounts, nextRun, successToday: records.filter(log => ['success', 'already_done'].includes(log.status)).length, failuresToday: records.filter(log => !['success', 'already_done'].includes(log.status)).length };
  });
  ipcMain.handle('accounts:create', (_event, input) => {
    if (!input || typeof input.name !== 'string' || !input.name.trim()) throw new Error('帳號名稱不可為空白');
    if (typeof input.cookie !== 'string' || input.cookie.trim().length < 10) throw new Error('請輸入有效的 HoYoLAB Cookie');
    const games = Array.isArray(input.games) ? input.games.filter(item => GAMES[item.game]).map(item => ({ ...item, enabled: true, checkinEnabled: Boolean(item.checkinEnabled), redeemEnabled: Boolean(item.redeemEnabled) })) : [];
    if (games.length === 0) throw new Error('請至少選擇一個遊戲');
    premium.assertCanCreateAccount(accountView().length); const id = crypto.randomUUID(); const secretRef = `cookie:${id}`;
    secrets.set(secretRef, input.cookie.trim());
    accounts.save({ id, name: input.name.trim(), enabled: true, secretRef, games }); database.persist();
    return accountView();
  });
  ipcMain.handle('accounts:create-from-hoyolab', async (_event, input) => {
    if (!input || typeof input.name !== 'string' || !input.name.trim()) throw new Error('帳號名稱不可為空白');
    const games = Array.isArray(input.games) ? input.games.filter(item => GAMES[item.game]).map(item => ({ ...item, enabled: true, checkinEnabled: Boolean(item.checkinEnabled), redeemEnabled: Boolean(item.redeemEnabled) })) : [];
    if (games.length === 0) throw new Error('請至少選擇一個遊戲');
    premium.assertCanCreateAccount(accountView().length); const result = await getHoyoLabCookie(); if (!result.ok) throw new Error(result.error);
    const id = crypto.randomUUID(); const secretRef = `cookie:${id}`; secrets.set(secretRef, result.cookie);
    accounts.save({ id, name: input.name.trim(), enabled: true, secretRef, games }); database.persist(); return accountView();
  });
  ipcMain.handle('accounts:set-enabled', (_event, id, enabled) => { accounts.setEnabled(id, enabled); return accountView(); });
  ipcMain.handle('accounts:update-cookie', (_event, id, cookie) => {
    if (typeof id !== 'string' || typeof cookie !== 'string' || cookie.trim().length < 10) throw new Error('請輸入有效的 HoYoLAB Cookie');
    const account = accounts.list().find(row => row.id === id); if (!account) throw new Error('找不到帳號');
    secrets.set(account.secretRef, cookie.trim()); return accountView();
  });
  ipcMain.handle('accounts:delete', (_event, id) => { const account = accounts.delete(id); if (!account) throw new Error('找不到帳號'); secrets.delete(account.secretRef); return accountView(); });
  ipcMain.handle('checkin:run', async (_event, options = {}) => checkins.run({ ...options, accountIds: manualAccountIds() }));
  ipcMain.handle('redeem:run', async (_event, value) => redeems.redeem({ ...value, accountIds: manualAccountIds() }));
  ipcMain.handle('codes:check', () => runCodes({ accountIds: manualAccountIds() }));
  ipcMain.handle('logs:latest', () => logs.latest());
  ipcMain.handle('schedule:get', () => ({ ...settings.get('schedule', { enabled: false, time: '04:00' }), enabled: Boolean(settings.get('schedule', { enabled: false }).enabled && premium.isPremium()), nextRun }));
  ipcMain.handle('schedule:set', (_event, value) => { const schedule = { enabled: Boolean(value.enabled), time: value.time }; if (schedule.enabled) premium.assert('dailySchedule'); scheduler.configure(schedule); settings.set('schedule', schedule); return { ...schedule, nextRun }; });
  ipcMain.handle('discord:get', () => settings.get('discord', { enabled: false, configured: Boolean(secrets.get('discord:webhook')) }));
  ipcMain.handle('discord:set', (_event, value) => { const enabled = Boolean(value.enabled); if (enabled) premium.assert('discord'); if (value.url) secrets.set('discord:webhook', value.url.trim()); settings.set('discord', { enabled }); return { enabled, configured: Boolean(secrets.get('discord:webhook')) }; });
  ipcMain.handle('discord:test', async () => { premium.assert('discord'); const url = secrets.get('discord:webhook'); await discord.send(url, 'HoYo Daily Sign-in：Discord Webhook 測試成功。'); return true; });
  ipcMain.handle('codes:polling-get', () => ({ ...settings.get('code_polling', { enabled: false, minutes: 30 }), enabled: Boolean(settings.get('code_polling', { enabled: false }).enabled && premium.isPremium()) }));
  ipcMain.handle('codes:polling-set', (_event, value) => { const config = { enabled: Boolean(value.enabled), minutes: Math.max(5, Math.min(1440, Number(value.minutes) || 30)) }; if (config.enabled) premium.assert('codePolling'); settings.set('code_polling', config); configureCodePolling(); return config; });
  ipcMain.handle('startup:get', () => ({ enabled: app.getLoginItemSettings().openAtLogin }));
  ipcMain.handle('startup:set', (_event, value) => { const enabled = Boolean(value.enabled); if (enabled) premium.assert('startup'); app.setLoginItemSettings({ openAtLogin: enabled, openAsHidden: enabled }); settings.set('startup', { enabled }); return { enabled: app.getLoginItemSettings().openAtLogin }; });
  ipcMain.handle('subscription:get', () => subscriptions.getStatus());
  ipcMain.handle('subscription:redeem-code', (_event, code) => { const result = subscriptions.redeemOfflineCode(code, LICENSE_PUBLIC_KEY_PEM); configureCodePolling(); return result; });
  createWindow();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (codeTimer) clearInterval(codeTimer); database?.close(); });
