'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('hoyoDaily', {
  dashboard: () => ipcRenderer.invoke('dashboard:get'),
  accounts: () => ipcRenderer.invoke('accounts:list'),
  createAccount: value => ipcRenderer.invoke('accounts:create', value),
  createFromHoyoLab: value => ipcRenderer.invoke('accounts:create-from-hoyolab', value),
  setAccountEnabled: (id, enabled) => ipcRenderer.invoke('accounts:set-enabled', id, enabled),
  updateCookie: (id, cookie) => ipcRenderer.invoke('accounts:update-cookie', id, cookie),
  deleteAccount: id => ipcRenderer.invoke('accounts:delete', id),
  runCheckin: options => ipcRenderer.invoke('checkin:run', options),
  redeem: value => ipcRenderer.invoke('redeem:run', value),
  checkCodes: () => ipcRenderer.invoke('codes:check'),
  discord: () => ipcRenderer.invoke('discord:get'),
  setDiscord: value => ipcRenderer.invoke('discord:set', value),
  testDiscord: () => ipcRenderer.invoke('discord:test'),
  codePolling: () => ipcRenderer.invoke('codes:polling-get'),
  setCodePolling: value => ipcRenderer.invoke('codes:polling-set', value),
  startup: () => ipcRenderer.invoke('startup:get'),
  setStartup: value => ipcRenderer.invoke('startup:set', value),
  subscription: () => ipcRenderer.invoke('subscription:get'),
  redeemLicenseCode: code => ipcRenderer.invoke('subscription:redeem-code', code),
  logs: () => ipcRenderer.invoke('logs:latest'),
  schedule: () => ipcRenderer.invoke('schedule:get'),
  setSchedule: value => ipcRenderer.invoke('schedule:set', value)
});
