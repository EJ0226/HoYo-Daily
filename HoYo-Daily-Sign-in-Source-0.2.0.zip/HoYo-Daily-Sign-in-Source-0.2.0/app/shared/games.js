'use strict';

const GAMES = Object.freeze({
  genshin: { id: 'genshin', name: '原神' },
  starrail: { id: 'starrail', name: '崩壞：星穹鐵道' },
  zzz: { id: 'zzz', name: '絕區零' }
});

function assertGame(game) {
  if (!GAMES[game]) throw new Error(`Unsupported game: ${game}`);
}

module.exports = { GAMES, assertGame };
