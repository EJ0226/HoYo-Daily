'use strict';
const test = require('node:test'); const assert = require('node:assert/strict'); const { RedeemManager } = require('../app/redeem/redeem_manager');
test('retries once after a redemption cooldown', async () => {
  const calls = []; let inserted = false; const db = { prepare: sql => ({ get: () => sql.includes('redeem_codes') && inserted ? { id: 1 } : undefined, run: () => { if (sql.includes('INSERT INTO redeem_codes')) inserted = true; } }), persist: () => {} }; const manager = new RedeemManager({ db, accounts: { activeForRedeem: () => [{ id: 'a', name: 'A', secretRef: 's' }] }, secrets: { get: () => 'cookie' }, logs: { write: () => {} }, client: { redeem: async () => { calls.push(1); return calls.length === 1 ? { status: 'cooldown', retryAfterMs: 1 } : { status: 'success', message: '兌換成功' }; } } });
  const result = await manager.redeem({ game: 'genshin', code: 'ABC123' }); assert.equal(calls.length, 2); assert.equal(result[0].status, 'success'); assert.equal(result[0].message, 'Code ABC123：兌換成功');
});
test('spaces distinct automatically discovered codes by ten seconds', async () => {
  const manager = Object.create(RedeemManager.prototype); const calls = []; manager.redeem = async item => { calls.push(item.code); return []; }; const waits = [];
  await manager.redeemMany([{ game: 'genshin', code: 'ONE1' }, { game: 'genshin', code: 'TWO2' }, { game: 'genshin', code: 'ONE1' }], { intervalMs: 10_000, wait: async ms => waits.push(ms) });
  assert.deepEqual(calls, ['ONE1', 'TWO2']); assert.deepEqual(waits, [10_000]);
});
