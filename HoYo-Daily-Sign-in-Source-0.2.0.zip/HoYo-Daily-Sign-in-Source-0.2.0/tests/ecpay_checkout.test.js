'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRecurringCheckout, createCheckMacValue } = require('../services/licensing-api/src/ecpay');

test('builds a signed recurring checkout with both ECPay callbacks', () => {
  const checkout = buildRecurringCheckout({ merchantId: '3002607', hashKey: 'hash-key', hashIv: 'hash-iv', actionUrl: 'https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5', returnUrl: 'https://billing.example.com/v1/ecpay/callback', periodReturnUrl: 'https://billing.example.com/v1/ecpay/callback', clientBackUrl: 'https://billing.example.com/payment-complete', tradeNo: 'HDTEST123', plan: { amount: 99, label: '月費', periodType: 'M', execTimes: '999' } });
  assert.equal(checkout.fields.PeriodAmount, '99'); assert.equal(checkout.fields.PeriodType, 'M'); assert.equal(checkout.fields.PeriodReturnURL, 'https://billing.example.com/v1/ecpay/callback');
  assert.equal(checkout.fields.CheckMacValue, createCheckMacValue(checkout.fields, { hashKey: 'hash-key', hashIv: 'hash-iv' }));
});
