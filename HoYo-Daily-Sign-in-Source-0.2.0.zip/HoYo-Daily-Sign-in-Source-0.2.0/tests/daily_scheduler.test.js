'use strict';
const test = require('node:test'); const assert = require('node:assert/strict'); const { nextRunAt, validateTime } = require('../app/core/daily_scheduler');
test('schedules tomorrow when todays time has passed', () => { const date = nextRunAt('04:00', new Date(2026, 7, 19, 5, 0)); assert.deepEqual([date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes()], [2026, 7, 20, 4, 0]); });
test('rejects invalid daily time', () => assert.throws(() => validateTime('25:00')));
