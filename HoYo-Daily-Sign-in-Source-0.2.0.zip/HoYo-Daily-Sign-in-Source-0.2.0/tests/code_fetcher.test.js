'use strict';
const test = require('node:test'); const assert = require('node:assert/strict'); const { CodeFetcher } = require('../app/redeem/code_fetcher');
test('maps upstream games and filters malformed codes', async () => { const fetcher = new CodeFetcher({ fetchImpl: async () => ({ ok: true, json: async () => ({ genshin: [{ code: 'abc123' }], hsr: [{ code: 'HSR999' }], zzz: [{ code: 'bad code' }] }) }) }); const values = await fetcher.fetchCodes(); assert.deepEqual(values.map(value => [value.game, value.code]), [['genshin', 'ABC123'], ['starrail', 'HSR999']]); });
