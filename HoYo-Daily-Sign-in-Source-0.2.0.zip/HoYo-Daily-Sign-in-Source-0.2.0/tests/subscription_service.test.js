'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { SubscriptionService } = require('../app/billing/subscription_service');
const { issueLicenseCode } = require('../app/billing/offline_license');
const crypto = require('node:crypto');

function repository(seed = {}) { const values = new Map(Object.entries(seed)); return { get: (key, fallback) => values.has(key) ? values.get(key) : fallback, set: (key, value) => values.set(key, value) }; }

test('starts a seven-day premium-service trial only once', () => {
  const now = new Date('2026-08-19T00:00:00.000Z'); const service = new SubscriptionService(repository(), { now: () => now });
  assert.equal(service.getStatus().status, 'not_started');
  assert.equal(service.startTrial().status, 'trial');
  assert.equal(service.getStatus().trialDaysRemaining, 7);
  now.setUTCDate(now.getUTCDate() + 8);
  assert.equal(service.getStatus().status, 'expired');
  assert.equal(service.startTrial().status, 'expired');
});

test('an active annual license supersedes an expired trial', () => {
  const now = new Date('2026-08-30T00:00:00.000Z'); const service = new SubscriptionService(repository({ subscription: { trialStartedAt: '2026-08-01T00:00:00.000Z' } }), { now: () => now });
  const result = service.setRemoteLicense({ planId: 'annual', paidUntil: '2027-08-30T00:00:00.000Z', licenseId: 'license-1' });
  assert.equal(result.status, 'active'); assert.equal(result.plan.id, 'annual'); assert.equal(result.plan.price, 599);
});

test('activates a signed seven-day offline trial only once on the same device', () => {
  const now = new Date('2026-08-19T00:00:00.000Z'); const keys = crypto.generateKeyPairSync('ed25519'); const privatePem = keys.privateKey.export({ type: 'pkcs8', format: 'pem' }); const publicPem = keys.publicKey.export({ type: 'spki', format: 'pem' }); const service = new SubscriptionService(repository(), { now: () => now });
  const code = issueLicenseCode({ privateKeyPem: privatePem, planId: 'trial7', id: 'trial-code-001' }); const activated = service.redeemOfflineCode(code, publicPem);
  assert.equal(activated.status, 'trial'); assert.equal(activated.trialDaysRemaining, 7);
  now.setUTCDate(now.getUTCDate() + 8); assert.equal(service.getStatus().status, 'expired'); assert.throws(() => service.redeemOfflineCode(code, publicPem), /已在此裝置使用過/);
});
