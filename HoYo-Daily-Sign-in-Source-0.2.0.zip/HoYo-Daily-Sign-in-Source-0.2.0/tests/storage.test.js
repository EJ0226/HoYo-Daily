'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { redact } = require('../app/storage/execution_log_repository');
const { openDatabase } = require('../app/storage/database');
const { AccountRepository } = require('../app/storage/account_repository');

test('redacts sensitive log fields recursively', () => {
  const safe = redact({ cookie: 'abc', nested: { webhookUrl: 'https://example.invalid' }, reason: 'failed' });
  assert.deepEqual(safe, { cookie: '********', nested: { webhookUrl: '********' }, reason: 'failed' });
});

test('persists enabled game configuration in SQLite', async () => {
  const db = await openDatabase(':memory:');
  const accounts = new AccountRepository(db);
  accounts.save({ id: 'main', name: 'Main', enabled: true, secretRef: 'credential:main', games: [
    { game: 'genshin', uid: '800000001', enabled: true, checkinEnabled: true, redeemEnabled: true }
  ] });
  assert.deepEqual(accounts.activeForCheckin('genshin').map(row => row.uid), ['800000001']);
  assert.deepEqual(accounts.activeForRedeem('genshin').map(row => row.uid), ['800000001']);
  db.close();
});
