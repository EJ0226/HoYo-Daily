'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { CheckinTaskManager, TaskStatus } = require('../app/core/checkin_task_manager');

test('continues after a failed account and does not expose a cookie in logs', async () => {
  const accounts = { activeForCheckin: () => [
    { id: 'a', name: 'Account A', game: 'genshin', secretRef: 'one' },
    { id: 'b', name: 'Account B', game: 'genshin', secretRef: 'two' }
  ] };
  const logs = { entries: [], write(entry) { this.entries.push(entry); } };
  const manager = new CheckinTaskManager({ accounts, secrets: { get: ref => ref === 'one' ? 'cookie_token=private' : 'ok-cookie' }, logs,
    checkinClient: { checkIn: async ({ cookie }) => { if (cookie.startsWith('cookie_token')) { const e = new Error(); e.code = 'AUTH_INVALID'; throw e; } return { status: TaskStatus.SUCCESS, message: 'Signed in' }; } } });
  const result = await manager.run({ games: ['genshin'] });
  assert.deepEqual(result.map(x => x.status), [TaskStatus.AUTH_INVALID, TaskStatus.SUCCESS]);
  assert.equal(logs.entries.some(x => JSON.stringify(x).includes('private')), false);
});
