'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { PremiumFeatureGate } = require('../app/billing/premium_feature_gate');

test('free plan permits one manual account but gates premium automation', () => {
  const gate = new PremiumFeatureGate({ getStatus: () => ({ isPremiumServiceActive: false }) });
  assert.doesNotThrow(() => gate.assertCanCreateAccount(0));
  assert.throws(() => gate.assertCanCreateAccount(1), /多帳號管理需要 Premium/);
  assert.throws(() => gate.assert('dailySchedule'), /每日自動簽到排程需要 Premium/);
  assert.deepEqual(gate.manualAccountIds([{ id: 'a' }, { id: 'b' }]), ['a']);
});

test('premium plan unlocks automation and all accounts', () => {
  const gate = new PremiumFeatureGate({ getStatus: () => ({ isPremiumServiceActive: true }) });
  assert.doesNotThrow(() => gate.assertCanCreateAccount(99));
  assert.doesNotThrow(() => gate.assert('discord'));
  assert.deepEqual(gate.manualAccountIds([{ id: 'a' }, { id: 'b' }]), ['a', 'b']);
});
