'use strict';
const test = require('node:test'); const assert = require('node:assert/strict');
// The test exercises the same allow-list policy used by the Electron login flow.
test('login import must retain only HoYoLAB credential cookies', () => {
  const permitted = new Set(['ltuid_v2', 'ltoken_v2']); const cookies = [{ name: 'ltuid_v2', value: '1' }, { name: 'ltoken_v2', value: 'secret' }, { name: 'analytics', value: 'x' }];
  const header = cookies.filter(cookie => permitted.has(cookie.name)).map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
  assert.equal(header, 'ltuid_v2=1; ltoken_v2=secret');
});
