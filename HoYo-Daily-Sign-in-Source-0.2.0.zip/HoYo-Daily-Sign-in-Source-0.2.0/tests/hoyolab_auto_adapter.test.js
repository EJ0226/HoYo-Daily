'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { HoyoLabAutoAdapter, normalizeCookie } = require('../app/hoyolab/hoyolab_auto_adapter');

test('returns already_done without issuing a sign request', async () => {
  let calls = 0;
  const client = new HoyoLabAutoAdapter({ fetchImpl: async () => { calls += 1; return { ok: true, json: async () => ({ retcode: 0, data: { is_sign: true } }) }; } });
  const result = await client.checkIn({ game: 'genshin', cookie: 'ltuid_v2=1; ltoken_v2=private-cookie' });
  assert.deepEqual(result, { status: 'already_done', message: '今日已簽到' }); assert.equal(calls, 1);
});

test('converts expired login response to auth_invalid', async () => {
  const client = new HoyoLabAutoAdapter({ fetchImpl: async () => ({ ok: true, json: async () => ({ retcode: -100, message: 'Login expired' }) }) });
  const result = await client.checkIn({ game: 'zzz', cookie: 'ltuid_v2=1; ltoken_v2=private-cookie' });
  assert.equal(result.status, 'auth_invalid');
});
test('normalizes a DevTools Cookie header without retaining unrelated values', () => {
  assert.equal(normalizeCookie('Cookie: ltuid_v2=1; ltoken_v2=abc; session=discard'), 'ltuid_v2=1; ltoken_v2=abc');
});
