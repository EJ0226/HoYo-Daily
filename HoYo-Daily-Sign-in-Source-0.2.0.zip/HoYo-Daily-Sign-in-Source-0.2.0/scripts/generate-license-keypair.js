'use strict';
const crypto = require('node:crypto'); const fs = require('node:fs'); const path = require('node:path');
const output = path.resolve(process.argv[2] || 'private'); const publicTarget = path.resolve(process.argv[3] || 'app/billing/license_public_key.js');
if (fs.existsSync(path.join(output, 'license-signing-private.pem'))) throw new Error(`私鑰已存在：${path.join(output, 'license-signing-private.pem')}。不會覆寫它。`);
const pair = crypto.generateKeyPairSync('ed25519'); const privatePem = pair.privateKey.export({ type: 'pkcs8', format: 'pem' }); const publicPem = pair.publicKey.export({ type: 'spki', format: 'pem' });
fs.mkdirSync(output, { recursive: true }); fs.writeFileSync(path.join(output, 'license-signing-private.pem'), privatePem, { mode: 0o600 }); fs.writeFileSync(path.join(output, 'license-signing-public.pem'), publicPem);
fs.writeFileSync(publicTarget, `'use strict';\n\n// Public verification key only. The private key must remain outside all releases.\nconst LICENSE_PUBLIC_KEY_PEM = \`${publicPem.trim()}\`;\n\nmodule.exports = { LICENSE_PUBLIC_KEY_PEM };\n`);
console.log(`已建立私鑰：${path.join(output, 'license-signing-private.pem')}`); console.log('私鑰不可上傳、不可寄給客戶、不可放入 EXE。'); console.log(`已更新公開驗證金鑰：${publicTarget}`);
