'use strict';
const crypto = require('node:crypto'); const fs = require('node:fs'); const path = require('node:path'); const { OFFLINE_PLANS, issueLicenseCode } = require('../app/billing/offline_license');
const [planId, recipient = '', note = ''] = process.argv.slice(2); if (!OFFLINE_PLANS[planId]) throw new Error('用法：node scripts/issue-license.js trial7|premium_month|premium_year "客戶名稱或訂單號" "備註"');
const privatePath = path.resolve(process.env.HOYO_LICENSE_PRIVATE_KEY || 'private/license-signing-private.pem'); if (!fs.existsSync(privatePath)) throw new Error(`找不到私鑰：${privatePath}`);
const serial = crypto.randomUUID(); const code = issueLicenseCode({ privateKeyPem: fs.readFileSync(privatePath, 'utf8'), planId, id: serial, note: `${recipient} ${note}`.trim() });
console.log(`方案：${OFFLINE_PLANS[planId].name}`); console.log(`序號：${serial}`); console.log(`授權碼：\n${code}`);
