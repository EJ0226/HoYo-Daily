# HoYo Daily 正式上線指南

這份指南適用於月費 NT$99、年費 NT$599 的 ECPay 定期定額。完成前，**不要把付款按鈕接到公開網站或宣傳程式**。

## 0. 上線判斷

目前完成：本機 7 天試用顯示、ECPay Checkout 建立、CheckMacValue 驗證、每期回呼、回呼重送防護、PostgreSQL 訂閱資料與 Docker 範本。

尚未完成且是正式收款前的阻擋項目：

- 網站會員登入與電子郵件驗證。
- 可供桌面程式登入的裝置授權／撤銷 API；現在桌面端尚未連接遠端付款狀態。
- 「管理訂閱／取消續訂」頁面及 ECPay 定期定額取消 API 串接。
- 正式的隱私權政策、服務條款、退款規則、客服信箱與發票／稅務流程。
- ECPay 測試環境的完整付款、每期回呼、失敗扣款、取消與退款測試。

在上述項目完成前，網站只能顯示「即將推出」，不得向使用者收款。

## 1. 你要先準備的資料

1. 網域，例如 `billing.example.com`，並能設定 DNS A/AAAA 或 CNAME。
2. 一台有 Docker Compose 的 Linux 主機，或等效的容器平台；需有固定公開 IP／網域與 HTTPS。
3. PostgreSQL 16 資料庫；可使用本範例的 Docker PostgreSQL，正式建議使用受管理資料庫與每日備份。
4. ECPay 特店帳號，且已由綠界開通「信用卡定期定額」。
5. 正式 ECPay MerchantID、HashKey、HashIV。它們只能存於部署平台的 Secrets，不能放入 Git、ZIP、前端、Electron 或網站 JavaScript。
6. 客服信箱、退款規則與隱私權政策 URL。

## 2. 建置一個隔離的正式環境

在 Linux 伺服器：

```bash
git clone <你的公開原始碼倉庫> hoyo-daily
cd hoyo-daily/services/licensing-api
cp .env.example .env
cp docker-compose.example.yml docker-compose.yml
```

編輯 `.env`。以下是欄位意義，示例值不可直接使用：

```dotenv
PORT=3000
DATABASE_SSL=false
ECPAY_ENV=stage
PUBLIC_URL=https://billing.example.com
ECPAY_MERCHANT_ID=綠界測試或正式MerchantID
ECPAY_HASH_KEY=綠界HashKey
ECPAY_HASH_IV=綠界HashIV
CHECKOUT_API_KEY=至少32字元的隨機秘密
```

產生 `CHECKOUT_API_KEY`：

```bash
openssl rand -hex 32
```

這個 API Key 只給你的**網站伺服器端**呼叫 `/v1/checkout` 時使用；不能放在瀏覽器、公開 JavaScript、手機 App 或 EXE。

將 `docker-compose.yml` 內兩處 `replace-with-a-long-random-password` 改為相同的長隨機 PostgreSQL 密碼。`.env`、`docker-compose.yml` 不可提交到公開 Git。

啟動：

```bash
docker compose up -d --build
curl -fsS http://127.0.0.1:3000/health
```

健康檢查預期回傳：

```json
{"ok":true}
```

## 3. HTTPS 與 DNS

1. 將 `billing.example.com` 的 DNS 指向你的伺服器。
2. 設定 nginx，將 [nginx.example.conf](../services/licensing-api/nginx.example.conf) 中的網域改成你的網域。
3. 使用 Certbot 或託管平台簽發 TLS 憑證。
4. 對外只開放 80/443；Docker 的 3000 僅綁定 `127.0.0.1`。
5. 從外網確認 `https://billing.example.com/health` 可連線。

`PUBLIC_URL` 必須和此 HTTPS 網域完全一致，不可使用內網 IP、localhost 或結尾帶 `/` 的網址。

## 4. ECPay 測試環境

1. 先在 `.env` 設定 `ECPAY_ENV=stage`，使用綠界測試 MerchantID、HashKey、HashIV。
2. 建立付款時，服務會使用測試網址 `https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5`；切換 `production` 才會使用正式網址。
3. 在你的網站**後端**以 `x-checkout-api-key` 呼叫：

```http
POST https://billing.example.com/v1/checkout
x-checkout-api-key: <CHECKOUT_API_KEY>
Content-Type: application/json

{"email":"buyer@example.com","planId":"monthly"}
```

4. 後端會回傳 `actionUrl` 與 `fields`。網站後端或安全的短期付款頁須以 HTML `POST` 表單把 `fields` 導向 `actionUrl`；不可把 HashKey／HashIV 傳到瀏覽器。
5. 完成 ECPay 測試卡付款後，確認：
   - `payment_orders` 有付款紀錄。
   - `payment_events` 有一筆 ECPay `TradeNo`。
   - `subscriptions.current_period_end` 已建立。
   - 重送相同 callback 時，`current_period_end` **不會再次延長**。
   - 每期付款通知也會打到 `https://billing.example.com/v1/ecpay/callback`。

綠界的定期定額是由 `PeriodAmount`、`PeriodType`、`Frequency`、`ExecTimes` 定義；本產品月費為 M/1/999，年費為 Y/1/99，且首期金額必須與每期金額相同。 [ECPay 定期定額文件](https://developers.ecpay.com.tw/2868/)

## 5. 切換正式金流

只有在所有測試成功後：

1. 向綠界確認正式帳號已開通信用卡定期定額。
2. 將 `.env` 改為 `ECPAY_ENV=production`，填入**正式**密鑰。
3. `docker compose up -d` 重新載入服務。
4. 用 NT$99 實際小額交易完整驗收，並測試綠界後台與資料庫相符。
5. 設定每日資料庫備份、異地備份與付款／callback 錯誤告警。

綠界會以 Server POST 傳送 ReturnURL；伺服器必須重新計算並驗證 `CheckMacValue`，且僅在 `RtnCode=1` 才授予服務。 [ECPay 回呼說明](https://developers.ecpay.com.tw/2858/)

## 6. 上線前安全與營運清單

- [ ] 前後端、ECPay、資料庫使用不同密碼與 Secrets。
- [ ] 所有 Secrets 只存在部署平台 Secret Store；已確認 Git 歷史、網站原始碼、EXE、日誌均無密鑰。
- [ ] 資料庫每日備份並每月演練還原。
- [ ] `/v1/checkout` 只接受網站後端持有的 API Key；已加上網站端 rate limit、CAPTCHA／登入驗證。
- [ ] ECPay callback 只依驗證後的 `CheckMacValue` 與 `RtnCode=1` 授權。
- [ ] 已測試 callback 重送、網路逾時、付款失敗、每期扣款失敗、取消訂閱、退款與客服申訴。
- [ ] 已做錯誤監控、付款失敗告警與備份告警。
- [ ] 有明確頁面說明價格、續訂頻率、取消方式、退款規則、客服聯絡方式與隱私權政策。
- [ ] 下載頁與 EXE 內保留 AGPL／第三方通知，並在同頁免費提供對應來源 ZIP。
- [ ] 不以訂閱限制 AGPL 軟體的再散布權；Premium 僅應對應可選的託管服務與支援。

## 7. 下一個必做開發階段

在公開收款前，請先完成「會員與裝置授權」：電子郵件驗證、登入、付款後綁定 customer、桌面程式安全登入、授權檢查、裝置上限與解除裝置、取消續訂流程。完成後，再將付款按鈕從「尚未設定」改成實際導向你的網站。
