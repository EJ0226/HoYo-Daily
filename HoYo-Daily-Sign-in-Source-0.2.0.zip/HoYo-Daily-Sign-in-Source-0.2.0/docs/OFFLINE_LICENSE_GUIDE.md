# 離線 Premium 授權碼操作指南

本模式不需要 ECPay、網域、伺服器或資料庫。授權碼由你的私鑰簽署，桌面程式只保留公開驗證金鑰。

## 重要安全規則

- 私鑰位置：`private/license-signing-private.pem`。
- **私鑰不可上傳 Git、網站、雲端硬碟公開連結、原始碼 ZIP，也不可傳給客戶。**
- 請將私鑰備份到加密隨身碟或密碼管理器的加密附件；遺失後無法簽發與現有 EXE 相容的新授權碼。
- 這是離線授權：使用者可分享碼或藉由重灌繞過「同一裝置只用一次」紀錄。若需要真正的一人一碼／裝置上限，未來仍需後端。

## 首次設定

已替你建立一組 Ed25519 金鑰：私鑰在 `private/`，公開金鑰已寫入 `app/billing/license_public_key.js`。

若日後要重建整套授權系統，執行：

```powershell
node scripts/generate-license-keypair.js
```

這會拒絕覆寫既有私鑰。**不要在已發布 EXE 後任意換金鑰**；換金鑰代表舊版 EXE 將無法驗證新碼。

## 簽發三種授權碼

在 `E:\hoyodaliy` 執行。第二個參數建議填訂單號或客戶代稱，方便你保留發碼紀錄：

```powershell
# 7 天免費體驗
node scripts/issue-license.js trial7 "訂單-001"

# Premium 1 個月（自使用者在程式輸入當天起算 30 天）
node scripts/issue-license.js premium_month "訂單-002"

# Premium 1 年（自使用者在程式輸入當天起算 365 天）
node scripts/issue-license.js premium_year "訂單-003"
```

工具會印出「方案、序號、授權碼」。只將 `HD1.…` 那一整串碼傳給客戶；序號與購買者資料請自己保存在私密的試算表或訂單系統。

## 使用者啟用流程

1. 使用者開啟 HoYo Daily Sign-in。
2. 前往「方案與授權」。
3. 貼上完整 `HD1.…` 授權碼。
4. 按「啟用 Premium」。
5. 程式顯示方案與有效期限；到期後會恢復免費狀態。

免費版功能不會因為到期被刪除。請只把你明確定義的加值功能設為 Premium，並維持 AGPL 應有的原始碼與散布權利。

## 發布新版 EXE 前

每次金鑰或授權程式變更後，必須重新執行：

```powershell
npm test
npm run dist
```

舊版與新版若使用同一個 `app/billing/license_public_key.js`，都可以驗證同一批授權碼。
