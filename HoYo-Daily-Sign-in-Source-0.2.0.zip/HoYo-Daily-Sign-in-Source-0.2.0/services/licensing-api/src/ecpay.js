'use strict';
const crypto = require('node:crypto');

function encodeForEcpay(value) {
  return encodeURIComponent(value).toLowerCase()
    .replace(/%2d/g, '-').replace(/%5f/g, '_').replace(/%2e/g, '.')
    .replace(/%21/g, '!').replace(/%2a/g, '*').replace(/%28/g, '(')
    .replace(/%29/g, ')').replace(/%20/g, '+');
}
function createCheckMacValue(params, { hashKey, hashIv }) {
  const pairs = Object.entries(params).filter(([key]) => key !== 'CheckMacValue').sort(([a], [b]) => a.localeCompare(b));
  const source = `HashKey=${hashKey}&${pairs.map(([key, value]) => `${key}=${value}`).join('&')}&HashIV=${hashIv}`;
  return crypto.createHash('md5').update(encodeForEcpay(source)).digest('hex').toUpperCase();
}
function ecpayDate(date = new Date()) {
  const pad = value => String(value).padStart(2, '0');
  return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}
function buildRecurringCheckout({ merchantId, hashKey, hashIv, actionUrl, returnUrl, periodReturnUrl, clientBackUrl, tradeNo, plan }) {
  const fields = {
    MerchantID: merchantId, MerchantTradeNo: tradeNo, MerchantTradeDate: ecpayDate(), PaymentType: 'aio', TotalAmount: String(plan.amount),
    TradeDesc: 'HoYo Daily Premium', ItemName: `HoYo Daily Premium ${plan.label}`, ReturnURL: returnUrl, PeriodReturnURL: periodReturnUrl, ClientBackURL: clientBackUrl,
    ChoosePayment: 'Credit', PeriodAmount: String(plan.amount), PeriodType: plan.periodType, Frequency: '1', ExecTimes: plan.execTimes
  };
  return { actionUrl, fields: { ...fields, CheckMacValue: createCheckMacValue(fields, { hashKey, hashIv }) } };
}
module.exports = { createCheckMacValue, buildRecurringCheckout };
