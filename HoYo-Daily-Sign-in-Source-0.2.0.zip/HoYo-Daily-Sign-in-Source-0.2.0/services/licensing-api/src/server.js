'use strict';
const crypto = require('node:crypto');
const express = require('express');
const { Pool } = require('pg');
const { createCheckMacValue, buildRecurringCheckout } = require('./ecpay');

const plans = { monthly: { id: 'monthly', amount: 99, label: '月費', periodType: 'M', execTimes: '999' }, annual: { id: 'annual', amount: 599, label: '年費', periodType: 'Y', execTimes: '99' } };
function required(name) { const value = process.env[name]; if (!value) throw new Error(`缺少環境變數 ${name}`); return value; }
function config() { const environment = process.env.ECPAY_ENV || 'stage'; if (!['stage', 'production'].includes(environment)) throw new Error('ECPAY_ENV 必須為 stage 或 production'); return { port: Number(process.env.PORT || 3000), databaseUrl: required('DATABASE_URL'), merchantId: required('ECPAY_MERCHANT_ID'), hashKey: required('ECPAY_HASH_KEY'), hashIv: required('ECPAY_HASH_IV'), checkoutApiKey: required('CHECKOUT_API_KEY'), publicUrl: required('PUBLIC_URL').replace(/\/$/, ''), environment }; }
function secureEquals(left, right) { const a = Buffer.from(left || ''); const b = Buffer.from(right || ''); return a.length === b.length && crypto.timingSafeEqual(a, b); }
function merchantTradeNo() { return `HD${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(5).toString('hex').toUpperCase()}`.slice(0, 20); }
function nextPeriod(plan, from = new Date()) { const result = new Date(from); if (plan.id === 'monthly') result.setMonth(result.getMonth() + 1); else result.setFullYear(result.getFullYear() + 1); return result; }

async function start() {
  const settings = config(); const db = new Pool({ connectionString: settings.databaseUrl, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined }); const web = express();
  web.use(express.urlencoded({ extended: false })); web.use(express.json());
  web.get('/health', async (_req, res) => { await db.query('SELECT 1'); res.json({ ok: true }); });
  web.post('/v1/checkout', async (req, res, next) => { try {
    if (!secureEquals(req.get('x-checkout-api-key'), settings.checkoutApiKey)) return res.status(401).json({ error: 'unauthorized' });
    const email = String(req.body.email || '').trim().toLowerCase(); const plan = plans[req.body.planId];
    if (!/^\S+@\S+\.\S+$/.test(email) || !plan) return res.status(400).json({ error: 'email 或 planId 無效' });
    const customerId = crypto.randomUUID(); const tradeNo = merchantTradeNo();
    const customer = await db.query('INSERT INTO customers (id, email) VALUES ($1, $2) ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email RETURNING id', [customerId, email]);
    await db.query('INSERT INTO payment_orders (merchant_trade_no, customer_id, plan_id, amount) VALUES ($1, $2, $3, $4)', [tradeNo, customer.rows[0].id, plan.id, plan.amount]);
    const actionUrl = settings.environment === 'production' ? 'https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5' : 'https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5';
    res.json(buildRecurringCheckout({ merchantId: settings.merchantId, hashKey: settings.hashKey, hashIv: settings.hashIv, actionUrl, returnUrl: `${settings.publicUrl}/v1/ecpay/callback`, periodReturnUrl: `${settings.publicUrl}/v1/ecpay/callback`, clientBackUrl: `${settings.publicUrl}/payment-complete`, tradeNo, plan }));
  } catch (error) { next(error); } });
  web.post('/v1/ecpay/callback', async (req, res, next) => { try {
    const expected = createCheckMacValue(req.body, settings); if (expected !== req.body.CheckMacValue) return res.status(400).send('0|CHECK_MAC_VALUE_INVALID');
    const order = await db.query('SELECT * FROM payment_orders WHERE merchant_trade_no = $1', [req.body.MerchantTradeNo]); if (!order.rowCount) return res.status(404).send('0|ORDER_NOT_FOUND');
    if (String(req.body.RtnCode) === '1') { const item = order.rows[0]; const plan = plans[item.plan_id]; const ecpayTradeNo = String(req.body.TradeNo || ''); if (!ecpayTradeNo) return res.status(400).send('0|TRADE_NO_MISSING');
      const client = await db.connect(); try { await client.query('BEGIN'); const inserted = await client.query('INSERT INTO payment_events (ecpay_trade_no, merchant_trade_no, status, raw_callback) VALUES ($1, $2, $3, $4) ON CONFLICT (ecpay_trade_no) DO NOTHING RETURNING ecpay_trade_no', [ecpayTradeNo, item.merchant_trade_no, 'paid', req.body]);
        if (inserted.rowCount) { const existing = await client.query('SELECT current_period_end FROM subscriptions WHERE customer_id = $1 FOR UPDATE', [item.customer_id]); const base = existing.rowCount && new Date(existing.rows[0].current_period_end) > new Date() ? new Date(existing.rows[0].current_period_end) : new Date(); await client.query('UPDATE payment_orders SET status = $1, paid_at = NOW(), raw_callback = $2 WHERE merchant_trade_no = $3', ['paid', req.body, item.merchant_trade_no]); await client.query('INSERT INTO subscriptions (customer_id, plan_id, status, current_period_end) VALUES ($1, $2, $3, $4) ON CONFLICT (customer_id) DO UPDATE SET plan_id = EXCLUDED.plan_id, status = EXCLUDED.status, current_period_end = EXCLUDED.current_period_end, updated_at = NOW()', [item.customer_id, plan.id, 'active', nextPeriod(plan, base)]); }
        await client.query('COMMIT');
      } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
    } res.send('1|OK');
  } catch (error) { next(error); } });
  web.use((error, _req, res, _next) => { console.error(error); res.status(500).json({ error: 'internal_error' }); });
  web.listen(settings.port, () => console.log(`licensing API listening on :${settings.port}`));
}
start().catch(error => { console.error(error); process.exitCode = 1; });
