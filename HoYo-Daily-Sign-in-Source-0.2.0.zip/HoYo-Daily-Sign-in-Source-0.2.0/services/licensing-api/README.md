# HoYo Daily Licensing API

獨立部署的訂閱服務。桌面程式不保存 ECPay 密鑰，也不傳送 HoYoLAB Cookie。

請依 [正式上線指南](../../docs/PRODUCTION_LAUNCH_GUIDE.md) 建置。Docker、PostgreSQL、nginx 與環境變數範例都在本資料夾。

`POST /v1/checkout` 接收 `{ "email": "user@example.com", "planId": "monthly" | "annual" }`，但只允許網站伺服器以 `x-checkout-api-key` 呼叫。回傳的 `actionUrl` 與 `fields` 必須以 HTML POST 表單導向 ECPay；HashKey／HashIV 不可傳到瀏覽器或 Electron。

使用 `.env.example` 建立 `.env`，從 ECPay 測試環境開始。回呼網址為 `https://你的網域/v1/ecpay/callback`，並同時作為首期與每期定期扣款的通知端點。
