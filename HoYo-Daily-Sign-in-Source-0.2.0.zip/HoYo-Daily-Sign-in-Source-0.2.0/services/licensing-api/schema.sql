CREATE TABLE IF NOT EXISTS customers (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_orders (
  merchant_trade_no TEXT PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES customers(id),
  plan_id TEXT NOT NULL CHECK (plan_id IN ('monthly', 'annual')),
  amount INTEGER NOT NULL CHECK (amount > 0),
  status TEXT NOT NULL DEFAULT 'pending',
  raw_callback JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  paid_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS subscriptions (
  customer_id UUID PRIMARY KEY REFERENCES customers(id),
  plan_id TEXT NOT NULL CHECK (plan_id IN ('monthly', 'annual')),
  status TEXT NOT NULL CHECK (status IN ('active', 'cancelled', 'past_due')),
  current_period_end TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ECPay may retry callbacks.  Every successful gateway TradeNo is accepted
-- once only, so a duplicate callback cannot extend a subscription twice.
CREATE TABLE IF NOT EXISTS payment_events (
  ecpay_trade_no TEXT PRIMARY KEY,
  merchant_trade_no TEXT NOT NULL REFERENCES payment_orders(merchant_trade_no),
  status TEXT NOT NULL,
  raw_callback JSONB NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
